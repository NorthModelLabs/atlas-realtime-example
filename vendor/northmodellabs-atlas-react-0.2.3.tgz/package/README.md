# @northmodellabs/atlas-react

React hook for [Atlas Realtime](https://docs.atlasv1.com) avatars. Handles LiveKit room, video/audio tracks, mic, transcriptions, and cleanup in a single `useAtlasSession()` call.

Supports two modes:

- **Passthrough** — default. Your application supplies audio.
- **Emotion** — your application supplies audio plus a bounded, text-free plan
  produced with `@northmodellabs/atlas-emotion`.

Atlas never runs STT, an LLM, prompting, or TTS for either mode.

## Install

```bash
npm install @northmodellabs/atlas-react livekit-client
```

## Passthrough mode (bring your own LLM + TTS)

```tsx
import { useAtlasSession } from "@northmodellabs/atlas-react";

function PassthroughPage() {
  const session = useAtlasSession({
    createSession: async (face) => {
      const res = await fetch("/api/session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ face_url: "https://...", mode: "passthrough" }),
      });
      return res.json();
    },
    deleteSession: async (id) => {
      await fetch(`/api/session/${id}`, { method: "DELETE" });
    },
    autoEnableMic: false, // we'll manage audio ourselves
  });

  const handleChat = async (text: string) => {
    // Call your own LLM + TTS backend
    const res = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text }),
    });
    const { audio } = await res.json(); // base64 MP3/WAV

    // Publish TTS audio to the room — avatar lip-syncs to it
    // Mic is auto-muted while playing, restored when done
    await session.publishAudio(audio);
  };

  return (
    <div>
      <div ref={session.videoRef} style={{ width: 512, height: 512 }} />
      {session.status === "connected" && (
        <button onClick={() => handleChat("Hello, tell me a joke")}>
          Ask a question
        </button>
      )}
    </div>
  );
}
```

### How `publishAudio` works

1. Decodes your audio (base64 string, Blob, or ArrayBuffer)
2. Mutes the user's mic so the avatar only lip-syncs to the AI voice
3. Publishes the audio as a LiveKit track — the avatar renders lip-sync and plays audio in real time
4. When playback ends, unpublishes the track and restores the mic

Returns a handle with `stop()` to cancel playback early:

```ts
const handle = await session.publishAudio(ttsAudio);
// later...
handle.stop(); // immediately stops playback + restores mic
```

## What the hook handles

- Creates a LiveKit `Room` with `dynacast` and a deterministic native-quality
  avatar subscription (adaptive stream is disabled for the single remote
  avatar video)
- Subscribes to video and audio tracks, attaches them to the DOM
- Enables microphone after the avatar video track attaches (configurable)
- Listens for `TranscriptionReceived` events and surfaces them as `messages`
- Measures round-trip latency
- Disconnects and cleans up on unmount and `beforeunload`
- Calls your `deleteSession` callback to tear down the server-side session

## Video readiness

With `autoEnableMic: true`, the hook waits for the `avatar_worker` video track to attach before marking the session connected and enabling the mic. This prevents a LiveKit room from accepting user audio while the UI is still showing an empty/black video container.

## API

### `useAtlasSession(options)`

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `createSession` | `(face, faceUrl) => Promise<SessionInfo>` | **required** | Creates a session on your backend |
| `deleteSession` | `(sessionId) => Promise<void>` | — | Tears down the session on your backend |
| `autoEnableMic` | `boolean` | `true` | Auto-enable mic after avatar video attaches |
| `autoCleanup` | `boolean` | `true` | Auto-disconnect on unmount / tab close |

### Returned `AtlasSession`

| Field | Type | Description |
|-------|------|-------------|
| `status` | `"idle" \| "connecting" \| "connected" \| "disconnected" \| "error"` | Connection state |
| `error` | `string \| null` | Error message if status is `"error"` |
| `sessionId` | `string \| null` | Active session ID |
| `messages` | `TranscriptMessage[]` | Transcript messages (check `.final` for completed) |
| `muted` | `boolean` | Whether mic is muted |
| `volume` | `number` | Playback volume (0–100) |
| `latency` | `number` | Round-trip time in ms |
| `videoRef` | `RefObject<HTMLDivElement>` | Attach to a `<div>` — video renders inside |
| `room` | `Room \| null` | LiveKit Room instance (null until connected) |
| `connect(face?, faceUrl?)` | `() => Promise<void>` | Start a session |
| `disconnect()` | `() => Promise<void>` | End the session |
| `setMicEnabled(enabled)` | `(boolean) => void` | Mute/unmute mic |
| `setVolume(v)` | `(number) => void` | Set playback volume 0–100 |
| `sendChat(text)` | `(string) => void` | Deprecated compatibility method; Atlas does not consume chat text |
| `publishAudio(audio)` | `(string \| Blob \| ArrayBuffer) => Promise<AudioPlaybackHandle>` | Publish TTS audio for avatar lip-sync (passthrough mode) |

## Backend proxy (required)

Your API key must stay server-side. Create a small API route that proxies to Atlas:

```ts
// Next.js example: app/api/session/route.ts
const API_KEY = process.env.ATLAS_API_KEY;
const API_URL = process.env.ATLAS_API_URL;

export async function POST(req: Request) {
  const form = await req.formData();
  const res = await fetch(`${API_URL}/v1/realtime/session`, {
    method: "POST",
    headers: { Authorization: `Bearer ${API_KEY}` },
    body: form,
  });
  return Response.json(await res.json(), { status: res.status });
}
```

## License

Apache-2.0
